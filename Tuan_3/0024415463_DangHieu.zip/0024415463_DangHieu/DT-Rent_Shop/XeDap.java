import java.math.BigDecimal;

public class XeDap extends PhuongTien {
    private static final BigDecimal GIA_MOI_GIO = BigDecimal.valueOf(15000);
    private static final BigDecimal TRAN_MOI_24H = BigDecimal.valueOf(100000);

    public XeDap() {
        super();
    }

    public XeDap(String maXe, String hangSX, int namSanXuat, TrangThaiXe trangThai) {
        super(maXe, hangSX, namSanXuat, trangThai);
    }

    @Override
    public boolean kiemTraGPLX(KhachHang khachHang) {
        return true;
    }

    @Override
    public BigDecimal tinhTienThue(PhieuThue p) {
        int tongSoGio = ThoiGian.soGioLamTronLen(p.getThoiGianThueThucTe());
        int soChuKy24h = tongSoGio / 24;   // mỗi 24 giờ trọn: 100.000
        int soGioConLai = tongSoGio % 24;  // phần lẻ: tối đa 100.000

        BigDecimal tienChuKy = TRAN_MOI_24H.multiply(BigDecimal.valueOf(soChuKy24h));
        BigDecimal tienLe = GIA_MOI_GIO.multiply(BigDecimal.valueOf(soGioConLai)).min(TRAN_MOI_24H);
        return tienChuKy.add(tienLe);
    }

    @Override
    public String getTenLoaiXe() {
        return "Xe đạp";
    }
}
