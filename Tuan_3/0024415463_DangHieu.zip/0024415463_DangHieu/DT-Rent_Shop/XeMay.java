import java.math.BigDecimal;

public class XeMay extends PhuongTienCoBienSo {
    private static final BigDecimal GIA_MOI_NGAY = BigDecimal.valueOf(150000);
    private static final BigDecimal PHAT_TRE_MOI_GIO = BigDecimal.valueOf(30000);

    public XeMay() {
        super();
    }

    public XeMay(String maXe, String hangSX, int namSanXuat, TrangThaiXe trangThai, String bienSo) {
        super(maXe, hangSX, namSanXuat, trangThai, bienSo);
    }

    @Override
    public boolean kiemTraGPLX(KhachHang khachHang) {
        return khachHang != null && khachHang.coGPLXMoto();
    }

    @Override
    public BigDecimal tinhTienThue(PhieuThue p) {
        int soNgay = ThoiGian.soNgayLamTronLen(p.getThoiGianThueDuKien());
        int gioTre = ThoiGian.soGioLamTronLen(p.getThoiGianTre());
        return GIA_MOI_NGAY.multiply(BigDecimal.valueOf(soNgay))
                .add(PHAT_TRE_MOI_GIO.multiply(BigDecimal.valueOf(gioTre)));
    }

    @Override
    public String getTenLoaiXe() {
        return "Xe máy";
    }
}
