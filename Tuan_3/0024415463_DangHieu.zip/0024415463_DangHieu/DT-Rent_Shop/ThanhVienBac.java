import java.math.BigDecimal;

public class ThanhVienBac extends KhachHang {

    public ThanhVienBac() {
        super();
    }

    public ThanhVienBac(String maKH, String hoTen, String soDienThoai) {
        super(maKH, hoTen, soDienThoai);
    }

    @Override
    public BigDecimal getPhanTramGiamGia() {
        return new BigDecimal("0.05");
    }

    @Override
    public String getTenHang() {
        return "Thành viên hạng Bạc";
    }
}
