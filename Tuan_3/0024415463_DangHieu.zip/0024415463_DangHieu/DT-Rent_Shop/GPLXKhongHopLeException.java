public class GPLXKhongHopLeException extends ThueXeException {
    public GPLXKhongHopLeException(String message) {
        super(message);
    }
}
