import java.time.Year;

public abstract class PhuongTien implements ITinhTienThue {
    private String maXe;
    private String hangSX;
    private int namSanXuat;
    private TrangThaiXe trangThai;

    public PhuongTien() {
        this.trangThai = TrangThaiXe.SAN_SANG;
    }

    public PhuongTien(String maXe, String hangSX, int namSanXuat, TrangThaiXe trangThai) {
        setMaXe(maXe);
        setHangSX(hangSX);
        setNamSanXuat(namSanXuat);
        setTrangThai(trangThai != null ? trangThai : TrangThaiXe.SAN_SANG);
    }

    public String getMaXe() {
        return maXe;
    }

    public void setMaXe(String maXe) {
        if (maXe == null || maXe.trim().isEmpty()) {
            throw new IllegalArgumentException("Mã xe không được để trống");
        }
        this.maXe = maXe.trim();
    }

    public String getHangSX() {
        return hangSX;
    }

    public void setHangSX(String hangSX) {
        if (hangSX == null || hangSX.trim().isEmpty()) {
            throw new IllegalArgumentException("Hãng sản xuất không được để trống");
        }
        this.hangSX = hangSX.trim();
    }

    public int getNamSanXuat() {
        return namSanXuat;
    }

    public void setNamSanXuat(int namSanXuat) {
        int currentYear = Year.now().getValue();
        if (namSanXuat < 1900 || namSanXuat > currentYear + 1) {
            throw new IllegalArgumentException("Năm sản xuất không hợp lệ (1900 - " + (currentYear + 1) + ")");
        }
        this.namSanXuat = namSanXuat;
    }

    public TrangThaiXe getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(TrangThaiXe trangThai) {
        if (trangThai == null) {
            throw new IllegalArgumentException("Trạng thái phương tiện không được null");
        }
        this.trangThai = trangThai;
    }

    public abstract boolean kiemTraGPLX(KhachHang khachHang);

    public abstract String getTenLoaiXe();

    @Override
    public String toString() {
        return String.format("[%s] Mã: %s, Hãng: %s, Năm SX: %d, Trạng thái: %s",
                getTenLoaiXe(), maXe, hangSX, namSanXuat, trangThai.getMoTa());
    }
}