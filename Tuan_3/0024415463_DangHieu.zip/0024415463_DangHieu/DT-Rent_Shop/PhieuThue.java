import java.math.BigDecimal;
import java.time.Duration;
import java.time.LocalDateTime;

public class PhieuThue {
    private String maPhieu;
    private KhachHang khachHang;
    private PhuongTien phuongTien;
    private LocalDateTime thoiDiemNhanXe;
    private LocalDateTime thoiDiemHenTra;
    private LocalDateTime thoiDiemTraThucTe;
    private int soKmDaDi;
    private BigDecimal tienGoc;
    private BigDecimal tienSauGiamGia;
    private boolean daTraXe;

    // Lập phiếu: kiểm tra điều kiện (mục 3), sai thì ném ngoại lệ
    public PhieuThue(String maPhieu, KhachHang khachHang, PhuongTien phuongTien,
                     LocalDateTime thoiDiemNhanXe, LocalDateTime thoiDiemHenTra) throws ThueXeException {
        if (maPhieu == null || maPhieu.trim().isEmpty()) {
            throw new IllegalArgumentException("Mã phiếu thuê không được để trống");
        }
        if (khachHang == null) {
            throw new IllegalArgumentException("Khách hàng không được null");
        }
        if (phuongTien == null) {
            throw new IllegalArgumentException("Phương tiện không được null");
        }
        if (thoiDiemNhanXe == null || thoiDiemHenTra == null || !thoiDiemHenTra.isAfter(thoiDiemNhanXe)) {
            throw new IllegalArgumentException("Thời điểm hẹn trả phải sau thời điểm nhận xe");
        }

        if (phuongTien.getTrangThai() != TrangThaiXe.SAN_SANG) {
            throw new TrangThaiXeKhongHopLeException(
                    "Từ chối lập phiếu: Phương tiện [" + phuongTien.getMaXe() + "] đang ở trạng thái '"
                            + phuongTien.getTrangThai().getMoTa() + "', không sẵn sàng cho thuê.");
        }

        if (!phuongTien.kiemTraGPLX(khachHang)) {
            throw new GPLXKhongHopLeException(
                    "Từ chối lập phiếu: Khách hàng " + khachHang.getHoTen()
                            + " không có GPLX phù hợp để thuê " + phuongTien.getTenLoaiXe() + ".");
        }

        this.maPhieu = maPhieu.trim();
        this.khachHang = khachHang;
        this.phuongTien = phuongTien;
        this.thoiDiemNhanXe = thoiDiemNhanXe;
        this.thoiDiemHenTra = thoiDiemHenTra;
        this.daTraXe = false;

        this.phuongTien.setTrangThai(TrangThaiXe.DANG_CHO_THUE);
    }

    // Trả xe: ghi nhận thời điểm trả thực tế (và số km), phiếu tự tính tiền
    public BigDecimal traXe(LocalDateTime thoiDiemTra) {
        return traXe(thoiDiemTra, 0, TrangThaiXe.SAN_SANG);
    }

    public BigDecimal traXe(LocalDateTime thoiDiemTra, int soKmDaDi) {
        return traXe(thoiDiemTra, soKmDaDi, TrangThaiXe.SAN_SANG);
    }

    public BigDecimal traXe(LocalDateTime thoiDiemTra, int soKmDaDi, TrangThaiXe trangThaiSauKhiTra) {
        if (daTraXe) {
            throw new IllegalStateException("Phiếu thuê này đã trả xe");
        }
        if (thoiDiemTra == null || !thoiDiemTra.isAfter(thoiDiemNhanXe)) {
            throw new IllegalArgumentException("Thời điểm trả phải sau thời điểm nhận xe");
        }
        if (soKmDaDi < 0) {
            throw new IllegalArgumentException("Số km đã đi không được âm");
        }

        this.thoiDiemTraThucTe = thoiDiemTra;
        this.soKmDaDi = soKmDaDi;

        this.tienGoc = phuongTien.tinhTienThue(this);                    // đa hình theo loại xe
        this.tienSauGiamGia = khachHang.tinhTienSauGiamGia(this.tienGoc); // đa hình theo loại khách
        this.daTraXe = true;
        this.phuongTien.setTrangThai(trangThaiSauKhiTra != null ? trangThaiSauKhiTra : TrangThaiXe.SAN_SANG);

        return this.tienSauGiamGia;
    }

    // Các mốc thời gian cho lớp phương tiện dùng để tính tiền
    public Duration getThoiGianThueDuKien() {
        return Duration.between(thoiDiemNhanXe, thoiDiemHenTra);
    }

    public Duration getThoiGianThueThucTe() {
        kiemTraDaGhiNhanTra();
        return Duration.between(thoiDiemNhanXe, thoiDiemTraThucTe);
    }

    public Duration getThoiGianTre() {
        kiemTraDaGhiNhanTra();
        return Duration.between(thoiDiemHenTra, thoiDiemTraThucTe);
    }

    private void kiemTraDaGhiNhanTra() {
        if (thoiDiemTraThucTe == null) {
            throw new IllegalStateException("Chưa ghi nhận thời điểm trả thực tế");
        }
    }

    public String getMaPhieu() {
        return maPhieu;
    }

    public KhachHang getKhachHang() {
        return khachHang;
    }

    public PhuongTien getPhuongTien() {
        return phuongTien;
    }

    public LocalDateTime getThoiDiemNhanXe() {
        return thoiDiemNhanXe;
    }

    public LocalDateTime getThoiDiemHenTra() {
        return thoiDiemHenTra;
    }

    public LocalDateTime getThoiDiemTraThucTe() {
        return thoiDiemTraThucTe;
    }

    public int getSoKmDaDi() {
        return soKmDaDi;
    }

    public BigDecimal getTienGoc() {
        return tienGoc;
    }

    public BigDecimal getTienSauGiamGia() {
        return tienSauGiamGia;
    }

    public boolean isDaTraXe() {
        return daTraXe;
    }
}
