import java.math.BigDecimal;

public interface ITinhTienThue {
    BigDecimal tinhTienThue(PhieuThue phieuThue);
}
