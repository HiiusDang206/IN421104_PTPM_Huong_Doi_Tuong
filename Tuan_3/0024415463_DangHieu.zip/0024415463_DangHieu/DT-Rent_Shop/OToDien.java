import java.math.BigDecimal;

public class OToDien extends PhuongTienCoBienSo {
    private static final BigDecimal GIA_MOI_NGAY = BigDecimal.valueOf(800000);
    private static final int KM_TOI_DA_MOI_NGAY = 200;
    private static final BigDecimal GIA_KM_VUOT = BigDecimal.valueOf(2000);

    public OToDien() {
        super();
    }

    public OToDien(String maXe, String hangSX, int namSanXuat, TrangThaiXe trangThai, String bienSo) {
        super(maXe, hangSX, namSanXuat, trangThai, bienSo);
    }

    @Override
    public boolean kiemTraGPLX(KhachHang khachHang) {
        return khachHang != null && khachHang.coGPLXOTo();
    }

    @Override
    public BigDecimal tinhTienThue(PhieuThue p) {
        int soNgay = ThoiGian.soNgayLamTronLen(p.getThoiGianThueDuKien());
        int kmVuot = Math.max(0, p.getSoKmDaDi() - KM_TOI_DA_MOI_NGAY * soNgay);
        return GIA_MOI_NGAY.multiply(BigDecimal.valueOf(soNgay))
                .add(GIA_KM_VUOT.multiply(BigDecimal.valueOf(kmVuot)));
    }

    @Override
    public String getTenLoaiXe() {
        return "Ô tô điện";
    }
}
