import java.math.BigDecimal;

public class KhachVangLai extends KhachHang {

    public KhachVangLai() {
        super();
    }

    public KhachVangLai(String maKH, String hoTen, String soDienThoai) {
        super(maKH, hoTen, soDienThoai);
    }

    @Override
    public BigDecimal getPhanTramGiamGia() {
        return BigDecimal.ZERO;
    }

    @Override
    public String getTenHang() {
        return "Khách vãng lai";
    }
}
