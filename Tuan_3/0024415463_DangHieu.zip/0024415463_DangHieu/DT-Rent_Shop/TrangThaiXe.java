public enum TrangThaiXe {
    SAN_SANG("Sẵn sàng"),
    DANG_CHO_THUE("Đang cho thuê"),
    DANG_BAO_TRI("Đang bảo trì");

    private final String moTa;

    TrangThaiXe(String moTa) {
        this.moTa = moTa;
    }

    public String getMoTa() {
        return moTa;
    }

    @Override
    public String toString() {
        return moTa;
    }
}
