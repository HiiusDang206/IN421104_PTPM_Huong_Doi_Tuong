public class ThueXeException extends Exception {
    public ThueXeException(String message) {
        super(message);
    }
}
