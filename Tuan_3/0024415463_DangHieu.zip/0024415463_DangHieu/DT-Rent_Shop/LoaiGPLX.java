public enum LoaiGPLX {
    MOTO("Giấy phép lái xe mô tô"),
    OTO("Giấy phép lái xe ô tô");

    private final String moTa;

    LoaiGPLX(String moTa) {
        this.moTa = moTa;
    }

    public String getMoTa() {
        return moTa;
    }

    @Override
    public String toString() {
        return moTa;
    }
}
