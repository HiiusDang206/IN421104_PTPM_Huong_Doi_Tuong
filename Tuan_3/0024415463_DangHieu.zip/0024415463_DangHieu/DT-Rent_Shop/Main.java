import java.io.PrintStream;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.time.LocalDateTime;

public class Main {

    private static final DecimalFormat df;
    private static int soLuongDat = 0;

    static {
        DecimalFormatSymbols symbols = new DecimalFormatSymbols();
        symbols.setGroupingSeparator('.');
        df = new DecimalFormat("#,##0 đ", symbols);
    }

    @FunctionalInterface
    private interface KichBanTien {
        BigDecimal chay() throws Exception;
    }

    @FunctionalInterface
    private interface KichBanLoi {
        void chay() throws Exception;
    }

    // Kịch bản tính tiền: so sánh kết quả thực tế với mong đợi
    private static void chayTien(String maTC, String tinhHuong, KichBanTien kichBan, long mongDoi) {
        BigDecimal expected = BigDecimal.valueOf(mongDoi);
        try {
            BigDecimal actual = kichBan.chay();
            boolean dat = actual.compareTo(expected) == 0;
            if (dat) {
                soLuongDat++;
            }
            inDongKetQua(maTC, tinhHuong, df.format(expected), df.format(actual), dat);
        } catch (Exception e) {
            inDongKetQua(maTC, tinhHuong, df.format(expected), "Lỗi: " + e.getMessage(), false);
        }
    }

    // Kịch bản từ chối: phải ném đúng loại ngoại lệ
    private static void chayLoi(String maTC, String tinhHuong, KichBanLoi kichBan,
                                Class<? extends ThueXeException> loiMongDoi, String moTaLoi) {
        String thucTe;
        boolean dat = false;
        try {
            kichBan.chay();
            thucTe = "Không báo lỗi";
        } catch (ThueXeException e) {
            dat = e.getClass() == loiMongDoi;
            thucTe = dat ? moTaLoi : "Lỗi khác: " + e.getMessage();
        } catch (Exception e) {
            thucTe = "Lỗi khác: " + e.getMessage();
        }
        if (dat) {
            soLuongDat++;
        }
        inDongKetQua(maTC, tinhHuong, moTaLoi, thucTe, dat);
    }

    public static void main(String[] args) {
        System.setOut(new PrintStream(System.out, true, StandardCharsets.UTF_8));

        System.out.println("=========================================================================================================");
        System.out.println("                  BÁO CÁO THỰC THI KIỂM THỬ KỊCH BẢN PHẦN C (CÂU 8)                     ");
        System.out.println("=========================================================================================================\n");
        System.out.printf("%-6s | %-52s | %-18s | %-18s | %-10s%n",
                "Mã TC", "Tình huống", "Kết quả mong đợi", "Kết quả thực tế", "Đánh giá");
        System.out.println("---------------------------------------------------------------------------------------------------------");

        LocalDateTime goc = LocalDateTime.of(2026, 10, 1, 8, 0);

        // Dữ liệu mẫu: khách hàng
        KhachHang vangLai = new KhachVangLai("KH01", "Nguyễn Văn An", "0912345678");
        vangLai.themGPLX(LoaiGPLX.MOTO);
        vangLai.themGPLX(LoaiGPLX.OTO);

        KhachHang hangVang = new ThanhVienVang("KH02", "Hoàng Thị Em", "0956789012");
        hangVang.themGPLX(LoaiGPLX.MOTO);

        KhachHang hangBac = new ThanhVienBac("KH03", "Đỗ Văn Giang", "0967890123");
        hangBac.themGPLX(LoaiGPLX.OTO);

        KhachHang chiCoMoTo = new KhachVangLai("KH04", "Vũ Thị Hạnh", "0978901234");
        chiCoMoTo.themGPLX(LoaiGPLX.MOTO);

        chayTien("TC01", "Khách vãng lai thuê xe đạp 3 giờ", () -> {
            PhuongTien xe = new XeDap("XD01", "Giant", 2023, TrangThaiXe.SAN_SANG);
            PhieuThue p = new PhieuThue("PT01", vangLai, xe, goc, goc.plusHours(3));
            return p.traXe(goc.plusHours(3));
        }, 45000);

        chayTien("TC02", "Khách vãng lai thuê xe đạp 27 giờ", () -> {
            PhuongTien xe = new XeDap("XD02", "Asama", 2023, TrangThaiXe.SAN_SANG);
            PhieuThue p = new PhieuThue("PT02", vangLai, xe, goc, goc.plusHours(27));
            return p.traXe(goc.plusHours(27));
        }, 145000);

        chayTien("TC03", "Khách vãng lai thuê xe máy 2 ngày, trễ 2h10m", () -> {
            PhuongTien xe = new XeMay("XM01", "Honda", 2022, TrangThaiXe.SAN_SANG, "66-P1 123.45");
            LocalDateTime hen = goc.plusDays(2);
            PhieuThue p = new PhieuThue("PT03", vangLai, xe, goc, hen);
            return p.traXe(hen.plusHours(2).plusMinutes(10));
        }, 390000);

        chayTien("TC04", "Khách vãng lai thuê ô tô điện 1 ngày, đi 350km", () -> {
            PhuongTien xe = new OToDien("OT01", "VinFast", 2024, TrangThaiXe.SAN_SANG, "66A-111.22");
            LocalDateTime hen = goc.plusDays(1);
            PhieuThue p = new PhieuThue("PT04", vangLai, xe, goc, hen);
            return p.traXe(hen, 350);
        }, 1100000);

        chayTien("TC05", "Như TC03, khách thành viên hạng Vàng", () -> {
            PhuongTien xe = new XeMay("XM02", "Yamaha", 2023, TrangThaiXe.SAN_SANG, "66-P2 345.67");
            LocalDateTime hen = goc.plusDays(2);
            PhieuThue p = new PhieuThue("PT05", hangVang, xe, goc, hen);
            return p.traXe(hen.plusHours(2).plusMinutes(10));
        }, 351000);

        chayTien("TC06", "Khách hạng Bạc thuê ô tô điện 2 ngày, đi 380km", () -> {
            PhuongTien xe = new OToDien("OT02", "VinFast", 2024, TrangThaiXe.SAN_SANG, "66A-333.44");
            LocalDateTime hen = goc.plusDays(2);
            PhieuThue p = new PhieuThue("PT06", hangBac, xe, goc, hen);
            return p.traXe(hen, 380);
        }, 1520000);

        chayLoi("TC07", "Khách chỉ có GPLX mô tô thuê ô tô điện", () -> {
            PhuongTien xe = new OToDien("OT03", "VinFast", 2024, TrangThaiXe.SAN_SANG, "66A-555.66");
            new PhieuThue("PT07", chiCoMoTo, xe, goc, goc.plusDays(1));
        }, GPLXKhongHopLeException.class, "Báo lỗi GPLX");

        chayLoi("TC08", "Thuê xe đang ở trạng thái Đang bảo trì", () -> {
            PhuongTien xe = new XeDap("XD03", "Thống Nhất", 2021, TrangThaiXe.DANG_BAO_TRI);
            new PhieuThue("PT08", vangLai, xe, goc, goc.plusHours(2));
        }, TrangThaiXeKhongHopLeException.class, "Báo lỗi trạng thái");

        System.out.println("---------------------------------------------------------------------------------------------------------");
        System.out.println("KẾT QUẢ TỔNG HỢP: " + soLuongDat + "/8 kịch bản ĐẠT.");
        System.out.println("=========================================================================================================");
    }

    private static void inDongKetQua(String maTC, String tinhHuong, String mongDoi, String thucTe, boolean dat) {
        System.out.printf("%-6s | %-52s | %-18s | %-18s | %-10s%n",
                maTC, tinhHuong, mongDoi, thucTe, dat ? "[ĐẠT]" : "[KHÔNG ĐẠT]");
    }
}
