import java.math.BigDecimal;

public class ThanhVienVang extends KhachHang {

    public ThanhVienVang() {
        super();
    }

    public ThanhVienVang(String maKH, String hoTen, String soDienThoai) {
        super(maKH, hoTen, soDienThoai);
    }

    @Override
    public BigDecimal getPhanTramGiamGia() {
        return new BigDecimal("0.10");
    }

    @Override
    public String getTenHang() {
        return "Thành viên hạng Vàng";
    }
}
