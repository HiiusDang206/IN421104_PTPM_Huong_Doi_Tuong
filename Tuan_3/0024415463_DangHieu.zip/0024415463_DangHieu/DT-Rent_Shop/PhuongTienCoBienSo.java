// Lớp trung gian: chỉ xe máy và ô tô điện mới có biển số
public abstract class PhuongTienCoBienSo extends PhuongTien {
    private String bienSo;

    public PhuongTienCoBienSo() {
        super();
    }

    public PhuongTienCoBienSo(String maXe, String hangSX, int namSanXuat,
                              TrangThaiXe trangThai, String bienSo) {
        super(maXe, hangSX, namSanXuat, trangThai);
        setBienSo(bienSo);
    }

    public String getBienSo() {
        return bienSo;
    }

    public void setBienSo(String bienSo) {
        if (bienSo == null || bienSo.trim().isEmpty()) {
            throw new IllegalArgumentException("Biển số không được để trống");
        }
        this.bienSo = bienSo.trim();
    }

    @Override
    public String toString() {
        return super.toString() + ", Biển số: " + bienSo;
    }
}
