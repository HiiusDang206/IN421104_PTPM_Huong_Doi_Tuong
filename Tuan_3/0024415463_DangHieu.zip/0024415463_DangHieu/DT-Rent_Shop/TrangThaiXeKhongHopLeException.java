public class TrangThaiXeKhongHopLeException extends ThueXeException {
    public TrangThaiXeKhongHopLeException(String message) {
        super(message);
    }
}
