import java.math.BigDecimal;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public abstract class KhachHang {
    private String maKH;
    private String hoTen;
    private String soDienThoai;
    private Set<LoaiGPLX> danhSachGPLX = new HashSet<>();

    public KhachHang() {
    }

    public KhachHang(String maKH, String hoTen, String soDienThoai) {
        setMaKH(maKH);
        setHoTen(hoTen);
        setSoDienThoai(soDienThoai);
    }

    public String getMaKH() {
        return maKH;
    }

    public void setMaKH(String maKH) {
        if (maKH == null || maKH.trim().isEmpty()) {
            throw new IllegalArgumentException("Mã khách hàng không được để trống");
        }
        this.maKH = maKH.trim();
    }

    public String getHoTen() {
        return hoTen;
    }

    public void setHoTen(String hoTen) {
        if (hoTen == null || hoTen.trim().isEmpty()) {
            throw new IllegalArgumentException("Họ tên không được để trống");
        }
        this.hoTen = hoTen.trim();
    }

    public String getSoDienThoai() {
        return soDienThoai;
    }

    public void setSoDienThoai(String soDienThoai) {
        if (soDienThoai == null || !soDienThoai.matches("^[0-9]{10}$")) {
            throw new IllegalArgumentException("Số điện thoại phải gồm đúng 10 chữ số");
        }
        this.soDienThoai = soDienThoai;
    }

    public Set<LoaiGPLX> getDanhSachGPLX() {
        return Collections.unmodifiableSet(danhSachGPLX);
    }

    public void themGPLX(LoaiGPLX gplx) {
        if (gplx != null) {
            this.danhSachGPLX.add(gplx);
        }
    }

    public void xoaGPLX(LoaiGPLX gplx) {
        this.danhSachGPLX.remove(gplx);
    }

    public boolean coGPLXMoto() {
        return danhSachGPLX.contains(LoaiGPLX.MOTO);
    }

    public boolean coGPLXOTo() {
        return danhSachGPLX.contains(LoaiGPLX.OTO);
    }

    public abstract BigDecimal getPhanTramGiamGia();

    public abstract String getTenHang();

    public BigDecimal tinhTienSauGiamGia(BigDecimal tongTienThue) {
        return tongTienThue.multiply(BigDecimal.ONE.subtract(getPhanTramGiamGia()));
    }

    @Override
    public String toString() {
        return String.format("%s - %s (%s, SĐT: %s)", maKH, hoTen, getTenHang(), soDienThoai);
    }
}