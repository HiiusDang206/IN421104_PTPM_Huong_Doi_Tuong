import java.time.Duration;

// Làm tròn LÊN bằng số nguyên, tránh sai số của số thực
public final class ThoiGian {
    private ThoiGian() {
    }

    private static int lamTronLen(Duration d, Duration donVi) {
        if (d.isZero() || d.isNegative()) {
            return 0;
        }
        long tu = d.toNanos();
        long mau = donVi.toNanos();
        return (int) ((tu + mau - 1) / mau);
    }

    public static int soGioLamTronLen(Duration d) {
        return lamTronLen(d, Duration.ofHours(1));
    }

    public static int soNgayLamTronLen(Duration d) {
        return lamTronLen(d, Duration.ofDays(1));
    }
}
